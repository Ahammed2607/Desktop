from django.apps import AppConfig


class HouserentmanagementappConfig(AppConfig):
    name = 'HouseRentManagementApp'
